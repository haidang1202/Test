# totinhcrush
Các bạn thay đổi tên ở thư mục Love 
Các bạn nhấn Ctrl + F và gõ Nguyễn Quang Nhất: Thay tên này bằng tên người yêu bạn
